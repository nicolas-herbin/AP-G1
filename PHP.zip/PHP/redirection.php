<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../CSS/redirection.css" rel="stylesheet" />
    <title>Document</title>
</head>

<body>



    </div>
    <div class="mainscreen">
        <div class="card">
            <div class="leftside">
                <img src="../IMG/4990224-removebg-preview.png" alt="">
            </div>
            <div class="rightside">
                <h1>Administrateur :</h1>

                <p>Veillez choisir votre page :</p>

                <button class="button" onclick="window.location.href='client.php'">Pre admission</button>
                <button class="button" onclick="window.location.href='admin.php'">Panel Admin</button>
                <button class="button" onclick="window.location.href='../index.php'">retour</button>
            </div>
        </div>
    </div>
</body>

</html>